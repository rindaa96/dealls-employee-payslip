package com.dealls.techtest.dto;

import lombok.*;
import java.math.BigDecimal;

@Data
public class ReimbursementDTO {
    private BigDecimal amount;
    private String description;
}
