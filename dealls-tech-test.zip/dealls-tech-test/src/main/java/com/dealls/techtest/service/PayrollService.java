package com.dealls.techtest.service;

import com.dealls.techtest.domain.AttendancePeriod;
import com.dealls.techtest.domain.Payslip;
import com.dealls.techtest.dto.AttendancePeriodDTO;

import java.util.List;

public interface PayrollService {
    public AttendancePeriod createAttendancePeriod(AttendancePeriodDTO period);
    public List<Payslip> runPayroll(Long periodId);
    public List<Payslip> getSummary(Long periodId);
}
