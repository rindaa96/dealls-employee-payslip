package com.dealls.techtest.repository;


import com.dealls.techtest.domain.Attendance;
import com.dealls.techtest.dto.EmployeeAttendanceCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    @Query(value = "SELECT * FROM payslip.attendance a WHERE a.check_in_date\\:\\:date = CURRENT_DATE and a.employee_id = :employeeId", nativeQuery = true)
    Attendance findByCheckInDateIsToday(Long employeeId);

    @Query(value = "SELECT * FROM payslip.attendance a WHERE a.check_out_date\\:\\:date = CURRENT_DATE and a.employee_id = :employeeId", nativeQuery = true)
    Attendance findByCheckOutDateIsToday(Long employeeId);

    @Query(value = """
    SELECT 
        a.employee_id AS employeeId, 
        COUNT(*) AS attendanceCount
    FROM 
        payslip.attendance a
    WHERE 
        a.check_in_date IS NOT NULL
        AND a.check_out_date IS NOT NULL
        AND a.check_in_date\\:\\:date BETWEEN :startDate AND :endDate
        AND a.check_out_date\\:\\:date BETWEEN :startDate AND :endDate
    GROUP BY 
        a.employee_id
    """, nativeQuery = true)
    List<EmployeeAttendanceCount> countAttendanceGroupedByEmployee(
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );



}
