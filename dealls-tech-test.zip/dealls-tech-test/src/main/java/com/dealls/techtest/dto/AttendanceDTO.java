package com.dealls.techtest.dto;

import lombok.*;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AttendanceDTO {
    private Long id;
    private ZonedDateTime checkInDate;
    private ZonedDateTime checkOutDate;
}
