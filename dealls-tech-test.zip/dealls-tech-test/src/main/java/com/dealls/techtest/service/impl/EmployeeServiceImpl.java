package com.dealls.techtest.service.impl;

import com.dealls.techtest.Utils.JwtUtil;
import com.dealls.techtest.constant.ErrorConstant;
import com.dealls.techtest.domain.*;
import com.dealls.techtest.dto.AttendanceDTO;
import com.dealls.techtest.dto.ReimbursementDTO;
import com.dealls.techtest.exception.BadRequestMessageException;
import com.dealls.techtest.exception.ResourceNotFoundException;
import com.dealls.techtest.repository.*;
import com.dealls.techtest.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import static com.dealls.techtest.Utils.CommonUtils.*;
import static com.dealls.techtest.constant.ErrorConstant.*;
import static java.time.LocalDate.now;

@RequiredArgsConstructor
@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {
    private final AttendanceRepository attendanceRepository;
    private final OvertimeRepository overtimeRepository;
    private final ReimburseRepository reimbursementRepository;
    private final PayslipRepository payslipRepository;
    private final EmployeeRepository employeeRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtil jwtUtil;
    @Override
    public AttendanceDTO submitAttendance(boolean isCheckIn) {

        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        DayOfWeek dayOfWeek = today.getDayOfWeek();

        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            throw new BadRequestMessageException(ATTENDANCE_WEEKEND);
        }

        Attendance attendance;
        Employee employee = Employee.builder().id(getId()).build();
        attendance = attendanceRepository.findByCheckInDateIsToday(getId());
        if (isCheckIn == true) {
            if (attendance != null) {
                attendance.setCheckInDate(ZonedDateTime.now());
                attendance.setModifiedDate(ZonedDateTime.now());
                attendance.setModifiedBy(getName());
            } else {
                attendance = Attendance.builder().employee(employee).checkInDate(ZonedDateTime.now())
                        .createdDate(ZonedDateTime.now()).createdBy(getName())
                        .modifiedDate(ZonedDateTime.now()).modifiedBy(getName()).build();
            }

        } else {
            attendance.setCheckOutDate(ZonedDateTime.now());
            attendance.setModifiedDate(ZonedDateTime.now());
            attendance.setModifiedBy(getName());
        }

        attendance = attendanceRepository.save(attendance);

        return AttendanceDTO.builder().id(attendance.getId())
                .checkInDate(attendance.getCheckInDate())
                .checkOutDate(attendance.getCheckOutDate()).build();
    }

    @Override
    public Overtime submitOvertime(Integer hoursOvertime) {

        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        DayOfWeek dayOfWeek = today.getDayOfWeek();

        if (dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY) {
            Attendance attendance = attendanceRepository.findByCheckOutDateIsToday(getId());
            if (attendance == null || attendance.getCheckOutDate() == null) {
                throw new BadRequestMessageException(OVERTIME_AFTER_CHECKOUT);
            }
        }

        if (hoursOvertime > 3) {
            throw new BadRequestMessageException(OVERTIME_MORE_THAN_3HOURS);
        }
        return overtimeRepository.save(Overtime.builder().employeeId(getId())
                                    .hours(hoursOvertime)
                                    .createdDate(ZonedDateTime.now()).createdBy(getName())
                                    .modifiedDate(ZonedDateTime.now()).modifiedBy(getName()).build());
    }

    @Override
    public Reimbursement submitReimbursement(ReimbursementDTO reimbursement) {
        return reimbursementRepository.save(Reimbursement.builder().employeeId(getId())
                .amount(reimbursement.getAmount()).description(reimbursement.getDescription())
                .createdDate(ZonedDateTime.now()).createdBy(getName())
                .modifiedDate(ZonedDateTime.now()).modifiedBy(getName()).build());
    }

    @Override
    public Payslip getPayslip(Long period) {
        return payslipRepository.findPayslipByEmployeeIdAndPeriodId(getId(), period);
    }

    @Override
    public Employee login(String username, String password) {
        Employee employee = employeeRepository.findByUsername(username).orElseThrow(() ->
                            new ResourceNotFoundException(ErrorConstant.ACCOUNT_INVALID));

        if (!passwordEncoder.matches(password, employee.getPassword())) {
            throw new BadRequestMessageException(ErrorConstant.WRONG_PASSWORD);
        }

        String jwtToken = jwtUtil.generateToken(employee.getId(), username);
        employee.setToken(jwtToken);
        employee = employeeRepository.save(employee);

        return employee;
    }
}
