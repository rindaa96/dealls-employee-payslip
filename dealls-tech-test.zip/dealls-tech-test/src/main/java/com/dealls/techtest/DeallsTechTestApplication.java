
package com.dealls.techtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan("com.dealls.techtest")
@EntityScan({"com.dealls.techtest.domain"})
@EnableAsync
@EnableScheduling
public class DeallsTechTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(DeallsTechTestApplication.class, args);
    }
}
