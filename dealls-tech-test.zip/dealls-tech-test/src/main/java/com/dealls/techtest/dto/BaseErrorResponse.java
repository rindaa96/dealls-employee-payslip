package com.dealls.techtest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class BaseErrorResponse implements Serializable {

  private static final long serialVersionUID = 3293414188037181384L;

  @JsonProperty("failure")
  private boolean failure;
  private Status status;

  @Data
  @AllArgsConstructor
  @Builder
  public static class Status implements Serializable{

    private static final long serialVersionUID = 175716376610751711L;
    private String code;
    private String text;
    private String type;
  }
}
