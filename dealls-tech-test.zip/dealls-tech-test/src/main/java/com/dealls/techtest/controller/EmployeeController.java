package com.dealls.techtest.controller;

import com.dealls.techtest.domain.*;
import com.dealls.techtest.dto.AttendanceDTO;
import com.dealls.techtest.dto.ReimbursementDTO;
import com.dealls.techtest.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/employee")
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping("/login")
    public ResponseEntity<Employee> employeeLogin(String username, String password) {
        return ResponseEntity.ok(employeeService.login(username, password));
    }

    @PostMapping("/attendance")
    public ResponseEntity<AttendanceDTO> submitAttendance(boolean isCheckIn) {
        return ResponseEntity.ok(employeeService.submitAttendance(isCheckIn));
    }

    @PostMapping("/overtime")
    public ResponseEntity<Overtime> submitOvertime(@RequestBody Integer hoursOvertime) {
        return ResponseEntity.ok(employeeService.submitOvertime(hoursOvertime));
    }

    @PostMapping("/reimbursement")
    public ResponseEntity<Reimbursement> submitReimbursement(@RequestBody ReimbursementDTO reimbursement) {
        return ResponseEntity.ok(employeeService.submitReimbursement(reimbursement));
    }

    @GetMapping("/payslip/{periodId}")
    public ResponseEntity<Payslip> getPayslip(@PathVariable Long periodId) {
        return ResponseEntity.ok(employeeService.getPayslip(periodId));
    }
}