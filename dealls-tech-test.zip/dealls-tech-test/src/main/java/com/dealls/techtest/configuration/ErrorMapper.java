package com.dealls.techtest.configuration;

import com.dealls.techtest.constant.ErrorConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class ErrorMapper {

    public ErrorConstant mapToErrorConstant(
            String errorConstantEnum,
            ErrorConstant defaultValue
    ) {
        log.info(errorConstantEnum);
        try {
            return ErrorConstant.valueOf(errorConstantEnum);
        } catch (Exception e) {
            return defaultValue;
        }
    }
}
