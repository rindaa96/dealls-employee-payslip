package com.dealls.techtest.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "attendance_period", schema = "payslip")
public class AttendancePeriod {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate startDate;
    private LocalDate endDate;
    @Column(name = "period", updatable = false, insertable = false)
    private Long period;
    private boolean isProcessed;
    @Column(name = "created_date", columnDefinition = "timestamptz", nullable = false)
    private LocalDate createdDate;

    @Column(name = "modified_date", columnDefinition = "timestamptz", nullable = false)
    private LocalDate modifiedDate;

    @Column(name = "created_by", length = 50)
    private String createdBy;

    @Column(name = "modified_by", length = 50)
    private String modifiedBy;
}
