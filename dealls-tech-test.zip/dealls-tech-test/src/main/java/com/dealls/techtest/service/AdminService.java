package com.dealls.techtest.service;

import com.dealls.techtest.domain.*;
import com.dealls.techtest.dto.ReimbursementDTO;
import lombok.SneakyThrows;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

public interface AdminService {
    public Admin login(String username, String password);

}
