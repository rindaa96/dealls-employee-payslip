package com.dealls.techtest.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class BaseException extends RuntimeException {
    private final String code;
    private final String text;
    private final HttpStatus httpStatus;

    public BaseException(String code, String text, HttpStatus httpStatus) {
        super();
        this.code = code;
        this.text = text;
        this.httpStatus = httpStatus;
    }

    public BaseException(String code, String text, HttpStatus httpStatus, Throwable t) {
        super(t);
        this.code = code;
        this.text = text;
        this.httpStatus = httpStatus;
    }
}

