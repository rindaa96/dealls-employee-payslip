package com.dealls.techtest.repository;

import com.dealls.techtest.domain.AttendancePeriod;
import com.dealls.techtest.domain.Payslip;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PayslipRepository extends JpaRepository<Payslip, Long> {
    Payslip findPayslipByEmployeeIdAndPeriodId(Long employeeId, Long periodId);
    List<Payslip> findAllByPeriodId(Long periodId);
}
