package com.dealls.techtest.service;

import com.dealls.techtest.domain.*;
import com.dealls.techtest.dto.AttendanceDTO;
import com.dealls.techtest.dto.ReimbursementDTO;

public interface EmployeeService {
    public AttendanceDTO submitAttendance(boolean isCheckIn);
    public Overtime submitOvertime(Integer hoursOvertime);
    public Reimbursement submitReimbursement(ReimbursementDTO reimbursement);
    public Payslip getPayslip(Long monthPeriod);
    public Employee login(String username, String password);
}
