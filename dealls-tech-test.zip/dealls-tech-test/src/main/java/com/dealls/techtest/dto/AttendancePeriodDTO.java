package com.dealls.techtest.dto;

import lombok.*;

import java.time.LocalDate;

@Data
public class AttendancePeriodDTO{
    private LocalDate startDate;
    private LocalDate endDate;
}
