package com.dealls.techtest.service.impl;

import com.dealls.techtest.constant.ErrorConstant;
import com.dealls.techtest.domain.AttendancePeriod;
import com.dealls.techtest.domain.Employee;
import com.dealls.techtest.domain.Overtime;
import com.dealls.techtest.domain.Payslip;
import com.dealls.techtest.dto.AttendancePeriodDTO;
import com.dealls.techtest.dto.EmployeeAttendanceCount;
import com.dealls.techtest.exception.BadRequestMessageException;
import com.dealls.techtest.repository.*;
import com.dealls.techtest.service.PayrollService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import static com.dealls.techtest.Utils.CommonUtils.getName;


@RequiredArgsConstructor
@Service
@Slf4j
public class PayrollServiceImpl implements PayrollService {
    private final EmployeeRepository employeeRepository;
    private final ReimburseRepository reimburseRepository;
    private final PayslipRepository payslipRepository;
    private final AttendancePeriodRepository attendancePeriodRepository;
    private final AttendanceRepository attendanceRepository;
    private final OvertimeRepository overtimeRepository;
    @Override
    public AttendancePeriod createAttendancePeriod(AttendancePeriodDTO period) {
        String adminName = getName();

        AttendancePeriod attendance = new AttendancePeriod();
        attendance.setStartDate(period.getStartDate());
        attendance.setEndDate(period.getEndDate());
        attendance.setProcessed(false);
        attendance.setCreatedBy(adminName);
        attendance.setModifiedBy(adminName);
        attendance.setCreatedDate(LocalDate.now());
        attendance.setModifiedDate(LocalDate.now());
        return attendancePeriodRepository.save(attendance);
    }

    @Override
    public List<Payslip> runPayroll(Long periodId) {
        String adminName = getName();
        AttendancePeriod attendancePeriod = attendancePeriodRepository.findAttendancePeriodByPeriod(periodId);
        if (attendancePeriod == null) {
            throw new BadRequestMessageException(ErrorConstant.ATTENDANCE_PERIOD_NOT_EXIST);
        }

        List<Payslip> payslipList = payslipRepository.findAllByPeriodId(attendancePeriod.getPeriod());
        if (payslipList.size() > 0) {
            throw new BadRequestMessageException(ErrorConstant.PAYSLIP_ALREADY_PROCEED);
        }

        List<EmployeeAttendanceCount> attendanceCount = attendanceRepository.countAttendanceGroupedByEmployee(
                                                                            attendancePeriod.getStartDate(),
                                                                            attendancePeriod.getEndDate());

        long duration = countDaysBetween(attendancePeriod.getStartDate(), attendancePeriod.getEndDate());
        long durationPerDay = 8;

        payslipList = new ArrayList<>();
        for (EmployeeAttendanceCount employeeAttendance : attendanceCount) {
            Employee employee = employeeRepository.findEmployeeById(employeeAttendance.getEmployeeId());

            Payslip payslip = new Payslip();
            payslip.setEmployeeId(employee.getId());

            BigDecimal basicSalary = calculateBasicSalary(employee.getSalary(),
                                                            employeeAttendance.getAttendanceCount(),
                                                            duration);
            BigDecimal reimbursement = reimburseRepository.sumReimbursementAmountByEmployeeIdAndDateRange(
                                                                employee.getId(),
                                                                attendancePeriod.getStartDate(),
                                                                attendancePeriod.getEndDate());
            Integer overtimeHoursTotal = overtimeRepository.sumOvertimeHoursByEmployeeIdAndDateRange(
                                                                employee.getId(),
                                                                attendancePeriod.getStartDate(),
                                                                attendancePeriod.getEndDate());

            BigDecimal hourlyRate = employee.getSalary()
                    .divide(BigDecimal.valueOf(duration * durationPerDay), 2, RoundingMode.HALF_UP);

            BigDecimal overtimeAmount = hourlyRate.multiply(BigDecimal.valueOf(overtimeHoursTotal)).multiply(BigDecimal.valueOf(2));
            BigDecimal takeHomePay = basicSalary.add(reimbursement).add(overtimeAmount);

            payslip.setTakeHomePay(takeHomePay);
            payslip.setOvertimeHours(overtimeHoursTotal);
            payslip.setReimbursementTotal(reimbursement);
            payslip.setPeriodId(attendancePeriod.getPeriod());
            payslip.setAttendanceDays(employeeAttendance.getAttendanceCount());
            payslip.setCreatedBy(adminName);
            payslip.setCreatedDate(ZonedDateTime.now());
            payslip.setModifiedBy(adminName);
            payslip.setModifiedDate(ZonedDateTime.now());

            payslip = payslipRepository.save(payslip);
            payslipList.add(payslip);
        }
        return payslipList;
    }

    @Override
    public List<Payslip> getSummary(Long periodId) {
        return payslipRepository.findAllByPeriodId(periodId);
    }

    private long countDaysBetween(LocalDate startDate, LocalDate endDate) {
        return ChronoUnit.DAYS.between(startDate, endDate);
    }

    private BigDecimal calculateBasicSalary(BigDecimal employeeSalary, long attendanceCount, long duration) {
        if (duration == 0) {
            throw new IllegalArgumentException("Duration must be greater than zero.");
        }

        // Convert longs to BigDecimal for precise division
        BigDecimal attendance = BigDecimal.valueOf(attendanceCount);
        BigDecimal durationBD = BigDecimal.valueOf(duration);

        // (employeeSalary * attendanceCount) / duration
        return employeeSalary
                .multiply(attendance)
                .divide(durationBD, 2, RoundingMode.HALF_UP); // 2 decimal places
    }
}
