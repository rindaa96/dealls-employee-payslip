package com.dealls.techtest.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "audit_log")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "table_name")
    private String tableName;

    @Column(name = "action")
    private String action;

    @Column(name = "record_id")
    private Integer recordId;

    @Column(name = "changed_at", columnDefinition = "timestamptz")
    private OffsetDateTime changedAt;

    @Column(name = "changed_by")
    private String changedBy;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "request_id")
    private UUID requestId;

    @Column(name = "details", columnDefinition = "jsonb")
    private String details;
}
