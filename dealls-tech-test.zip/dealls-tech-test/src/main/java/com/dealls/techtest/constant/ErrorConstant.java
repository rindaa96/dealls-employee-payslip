package com.dealls.techtest.constant;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ErrorConstant {
    INVALID_TOKEN("98", "Invalid Token"),
    INTERNAL_SERVER_ERROR("66", "Internal Server Error"),
    INVALID_REQUEST("153", "Invalid Request"),
    ACCOUNT_INVALID("01", "Username atau password is invalid"),
    WRONG_PASSWORD("02", "your password is invalid"),
    ALREADY_CHECKIN("03", "you are already check-in today"),
    ALREADY_CHECKOUT("04", "you are already check-out today"),
    ATTENDANCE_WEEKEND("05", "Check-in and check-out are not allowed on weekends."),
    OVERTIME_MORE_THAN_3HOURS("06", "Overtime cannot be more than 3 hours per day"),
    OVERTIME_AFTER_CHECKOUT("07", "Overtime must be proposed after you are done working"),
    ATTENDANCE_PERIOD_NOT_EXIST("08", "Attendance Period doesn't exist"),
    PAYSLIP_ALREADY_PROCEED("09", "Payslip in the period already proceed");
    private final String code;
    private final String message;
}
