package com.dealls.techtest.exception;

import com.dealls.techtest.constant.ErrorConstant;
import org.springframework.http.HttpStatus;

public class ResourceNotFoundException extends BaseException {

    public ResourceNotFoundException(ErrorConstant errorConstant) {
        super(errorConstant.getCode(), errorConstant.getMessage(), HttpStatus.NOT_FOUND);
    }

    public ResourceNotFoundException(String code, String text) {
        super(code, text, HttpStatus.NOT_FOUND);
    }

    public ResourceNotFoundException(ErrorConstant errorConstant, Throwable t) {
        super(errorConstant.getCode(), errorConstant.getMessage(), HttpStatus.NOT_FOUND, t);
    }

    public ResourceNotFoundException(String code, String text, Throwable t) {
        super(code, text, HttpStatus.NOT_FOUND, t);
    }
}
