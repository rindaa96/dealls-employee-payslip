package com.dealls.techtest.configuration;

import com.dealls.techtest.Utils.JwtUtil;
import com.dealls.techtest.constant.ErrorConstant;
import com.dealls.techtest.domain.Admin;
import com.dealls.techtest.domain.Employee;
import com.dealls.techtest.dto.UsernameAndId;
import com.dealls.techtest.exception.BadRequestMessageException;
import com.dealls.techtest.exception.ResourceNotFoundException;
import com.dealls.techtest.repository.AdminRepository;
import com.dealls.techtest.repository.EmployeeRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import static com.dealls.techtest.constant.Headers.X_ID;
import static com.dealls.techtest.constant.Headers.X_USERNAME;

@Component
public class TokenAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String path = request.getRequestURI();

        if (path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs") ||
                path.equals("/admin/login") || path.equals("/employee/login")) {
            filterChain.doFilter(request, response);
            return;
        }

        try {
            String authHeader = request.getHeader("Authorization");
            if (authHeader != null && authHeader.startsWith("Bearer ")) {
                String token = authHeader.substring(7);

                if (jwtUtil.validateToken(token)) {
                    UsernameAndId usernameAndId = jwtUtil.getUsernameAndIdFromToken(token);
                    String role = null;

                    if (path.startsWith("/admin")) {
                        Admin admin = adminRepository.findByUsername(usernameAndId.getUsername())
                                .orElseThrow(() -> new BadRequestMessageException(ErrorConstant.ACCOUNT_INVALID));
                        if (token.equals(admin.getToken())) {
                            role = "ROLE_ADMIN";
                        }
                    } else if (path.startsWith("/employee")) {
                        Employee employee = employeeRepository.findByUsername(usernameAndId.getUsername())
                                .orElseThrow(() -> new BadRequestMessageException(ErrorConstant.ACCOUNT_INVALID));
                        if (token.equals(employee.getToken())) {
                            role = "ROLE_EMPLOYEE";
                        }
                    }

                    if (usernameAndId.getUsername() != null && role != null) {
                        UserDetails userDetails = new User(usernameAndId.getUsername(), "",
                                Collections.singletonList(new SimpleGrantedAuthority(role)));

                        UsernamePasswordAuthenticationToken authentication =
                                new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());

                        SecurityContextHolder.getContext().setAuthentication(authentication);

                        HttpServletRequest wrappedRequest = wrapRequestWithUserInfo(request, usernameAndId);
                        filterChain.doFilter(wrappedRequest, response);
                        return;
                    }
                }
            }

            // Token is missing or invalid
            throw new org.springframework.security.core.AuthenticationException("Invalid or missing token") {};
        } catch (BadRequestMessageException ex) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.setContentType("application/json");
            response.getWriter().write("""
                {
                  "code": "%s",
                  "message": "%s",
                  "status": 400,
                  "timestamp": "%s"
                }
                """.formatted(
                    ex.getCode(),
                    ex.getText(),
                    ZonedDateTime.now()
            ));
        } catch (Exception ex) {
            // All other errors — fallback to 401 (let the entry point handle it)
            SecurityContextHolder.clearContext();
            throw new org.springframework.security.core.AuthenticationException("Authentication failed", ex) {};
        }
    }

    private HttpServletRequest wrapRequestWithUserInfo(HttpServletRequest request, UsernameAndId usernameAndId) {
        String finalUsername = usernameAndId.getUsername();
        Long finalId = usernameAndId.getId();

        return new HttpServletRequestWrapper(request) {
            @Override
            public String getHeader(String name) {
                if (X_USERNAME.equalsIgnoreCase(name)) {
                    return finalUsername;
                } else if (X_ID.equalsIgnoreCase(name)) {
                    return String.valueOf(finalId);
                }
                return super.getHeader(name);
            }

            @Override
            public Enumeration<String> getHeaderNames() {
                List<String> headerNames = Collections.list(super.getHeaderNames());
                if (!headerNames.contains(X_USERNAME)) headerNames.add(X_USERNAME);
                if (!headerNames.contains(X_ID)) headerNames.add(X_ID);
                return Collections.enumeration(headerNames);
            }

            @Override
            public Enumeration<String> getHeaders(String name) {
                if (X_USERNAME.equalsIgnoreCase(name)) {
                    return Collections.enumeration(Collections.singletonList(finalUsername));
                } else if (X_ID.equalsIgnoreCase(name)) {
                    return Collections.enumeration(Collections.singletonList(String.valueOf(finalId)));
                }
                return super.getHeaders(name);
            }
        };
    }
}
