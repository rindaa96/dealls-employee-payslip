package com.dealls.techtest.controller;

import com.dealls.techtest.dto.ErrorResponse;
import com.dealls.techtest.exception.BadRequestMessageException;
import com.dealls.techtest.exception.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.ZonedDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BadRequestMessageException.class)
    public ResponseEntity<ErrorResponse> handleBadRequest(BadRequestMessageException ex) {
        return new ResponseEntity<>(new ErrorResponse(
                ex.getCode(),
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                ZonedDateTime.now()
        ), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(ResourceNotFoundException ex) {
        return new ResponseEntity<>(new ErrorResponse(
                ex.getCode(),
                ex.getMessage(),
                HttpStatus.NOT_FOUND.value(),
                ZonedDateTime.now()
        ), HttpStatus.NOT_FOUND);
    }

    // Catch-all
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex) {
        return new ResponseEntity<>(new ErrorResponse(
                "INTERNAL_ERROR",
                ex.getMessage(),
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                ZonedDateTime.now()
        ), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
