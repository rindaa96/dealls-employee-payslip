package com.dealls.techtest.exception;

import com.dealls.techtest.constant.ErrorConstant;
import org.springframework.http.HttpStatus;


public class UnauthorizedException extends BaseException {

  public UnauthorizedException() {
    super(ErrorConstant.INVALID_TOKEN.getCode(), ErrorConstant.INVALID_TOKEN.getMessage(), HttpStatus.UNAUTHORIZED);
  }
}
