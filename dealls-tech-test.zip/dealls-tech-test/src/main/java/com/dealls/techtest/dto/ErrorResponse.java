package com.dealls.techtest.dto;

import java.time.ZonedDateTime;

public class ErrorResponse {
    private String code;
    private String message;
    private int status;
    private ZonedDateTime timestamp;

    public ErrorResponse(String code, String message, int status, ZonedDateTime timestamp) {
        this.code = code;
        this.message = message;
        this.status = status;
        this.timestamp = timestamp;
    }

}
