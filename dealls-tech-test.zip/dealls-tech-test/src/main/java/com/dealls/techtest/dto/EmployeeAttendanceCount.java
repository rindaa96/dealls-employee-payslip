package com.dealls.techtest.dto;

public interface EmployeeAttendanceCount {
    Long getEmployeeId();
    Integer getAttendanceCount();
}

