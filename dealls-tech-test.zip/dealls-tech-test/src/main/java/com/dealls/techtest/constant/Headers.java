package com.dealls.techtest.constant;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Headers {
  public static final String X_APPLICATION_TOKEN = "X-Application-Token";
  public static final String X_USERNAME = "X-UserName";
  public static final String X_ID = "X-Id";
}
