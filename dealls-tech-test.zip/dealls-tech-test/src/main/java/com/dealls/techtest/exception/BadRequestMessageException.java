package com.dealls.techtest.exception;

import com.dealls.techtest.constant.ErrorConstant;
import org.springframework.http.HttpStatus;

public class BadRequestMessageException extends BaseException {

    public BadRequestMessageException(ErrorConstant errorConstant) {
        super(errorConstant.getCode(), errorConstant.getMessage(), HttpStatus.BAD_REQUEST);
    }

    public BadRequestMessageException(String code, String text) {
        super(code, text, HttpStatus.BAD_REQUEST);
    }

    public BadRequestMessageException(ErrorConstant errorConstant, Throwable t) {
        super(errorConstant.getCode(), errorConstant.getMessage(), HttpStatus.BAD_REQUEST, t);
    }

    public BadRequestMessageException(String code, String text, Throwable t) {
        super(code, text, HttpStatus.BAD_REQUEST, t);
    }
}

