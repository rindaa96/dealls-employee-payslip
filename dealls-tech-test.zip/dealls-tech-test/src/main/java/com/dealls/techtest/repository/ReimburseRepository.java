package com.dealls.techtest.repository;

import com.dealls.techtest.domain.Reimbursement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface ReimburseRepository extends JpaRepository<Reimbursement, Long> {
    @Query(value = """
        SELECT COALESCE(SUM(r.amount), 0)
        FROM payslip.reimbursement r
        WHERE r.employee_id = :employeeId
        AND r.created_date\\:\\:date BETWEEN :startDate AND :endDate
    """, nativeQuery = true)
    BigDecimal sumReimbursementAmountByEmployeeIdAndDateRange(
            @Param("employeeId") Long employeeId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );
}
