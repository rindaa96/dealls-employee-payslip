package com.dealls.techtest.controller;

import com.dealls.techtest.domain.Admin;
import com.dealls.techtest.domain.AttendancePeriod;
import com.dealls.techtest.domain.Payslip;
import com.dealls.techtest.dto.AttendancePeriodDTO;
import com.dealls.techtest.service.AdminService;
import com.dealls.techtest.service.PayrollService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Validated
@RequiredArgsConstructor
@RestController
@RequestMapping("/admin")
public class AdminController {

    private final PayrollService payrollService;
    private final AdminService adminService;

    @PostMapping("/login")
    public ResponseEntity<Admin> employeeLogin(String username, String password) {
        return ResponseEntity.ok(adminService.login(username, password));
    }

    @PostMapping("/attendance-period")
    public ResponseEntity<AttendancePeriod> createAttendancePeriod(@RequestBody AttendancePeriodDTO period) {
        return ResponseEntity.ok(payrollService.createAttendancePeriod(period));
    }

    @PostMapping("/run-payroll")
    public ResponseEntity<List<Payslip>> runPayroll(@RequestBody Long periodId) {
        return ResponseEntity.ok(payrollService.runPayroll(periodId));
    }

    @GetMapping("/summary/{periodId}")
    public ResponseEntity<List<Payslip>> getSummary(@PathVariable Long periodId) {
        return ResponseEntity.ok(payrollService.getSummary(periodId));
    }
}
