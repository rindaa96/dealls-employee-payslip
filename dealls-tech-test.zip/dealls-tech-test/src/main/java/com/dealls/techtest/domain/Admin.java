package com.dealls.techtest.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Data
@Table(name = "admins", schema = "payslip")
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", nullable = false, length = 50)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "created_at", columnDefinition = "timestamptz", nullable = false)
    private LocalDate createdAt;

    @Column(name = "updated_at", columnDefinition = "timestamptz", nullable = false)
    private LocalDate updatedAt;

    @Column(name = "created_by", length = 50)
    private String createdBy;

    @Column(name = "updated_by", length = 50)
    private String updatedBy;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "request_id")
    private UUID requestId;

    @Column(name = "token")
    private String token;
}

