package com.dealls.techtest.repository;

import com.dealls.techtest.domain.AttendancePeriod;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendancePeriodRepository extends JpaRepository<AttendancePeriod, Long> {
    AttendancePeriod findAttendancePeriodByPeriod(Long periodId);
}
