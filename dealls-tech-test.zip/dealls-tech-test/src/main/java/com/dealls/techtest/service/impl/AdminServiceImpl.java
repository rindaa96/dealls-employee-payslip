package com.dealls.techtest.service.impl;

import com.dealls.techtest.Utils.JwtUtil;
import com.dealls.techtest.constant.ErrorConstant;
import com.dealls.techtest.domain.*;
import com.dealls.techtest.exception.BadRequestMessageException;
import com.dealls.techtest.exception.ResourceNotFoundException;
import com.dealls.techtest.repository.*;
import com.dealls.techtest.service.AdminService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
@Slf4j
public class AdminServiceImpl implements AdminService {
    private final AdminRepository adminRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private JwtUtil jwtUtil;
    @Override
    public Admin login(String username, String password) {
        System.out.println("admin : " + username);
        Admin admin = adminRepository.findByUsername(username).orElseThrow(() ->
                new ResourceNotFoundException(ErrorConstant.ACCOUNT_INVALID));
        System.out.println("admin : " + admin.getUsername());

        if (!passwordEncoder.matches(password, admin.getPassword())) {
            throw new BadRequestMessageException(ErrorConstant.WRONG_PASSWORD);
        }

        String jwtToken = jwtUtil.generateToken(admin.getId(), username);
        admin.setToken(jwtToken);
        admin = adminRepository.save(admin);

        
        return admin;
    }

}
