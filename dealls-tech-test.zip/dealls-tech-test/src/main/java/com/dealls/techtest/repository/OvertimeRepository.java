package com.dealls.techtest.repository;


import com.dealls.techtest.domain.Attendance;
import com.dealls.techtest.domain.Overtime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;

public interface OvertimeRepository extends JpaRepository<Overtime, Long> {
    @Query(value = """
    SELECT COALESCE(SUM(o.hours), 0) 
    FROM payslip.overtime o 
    WHERE o.employee_id = :employeeId 
      AND o.created_date\\:\\:date BETWEEN :startDate AND :endDate
    """, nativeQuery = true)
    Integer sumOvertimeHoursByEmployeeIdAndDateRange(
            @Param("employeeId") Long employeeId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

}
